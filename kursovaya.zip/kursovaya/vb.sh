cd /home/hobbit/Documents/fasm/ #change by way to your directory
./fasm os.asm q.bin > /dev/null 
mkisofs -b q.bin -o q.iso q.bin  2> /dev/null
rm q.bin
virtualbox --startvm MyVM  2> /dev/null 
# To use last command you need install virtualbox, create there new virtual mashine 
# "MyVM" and make thete CD drive with q.iso from your path  
